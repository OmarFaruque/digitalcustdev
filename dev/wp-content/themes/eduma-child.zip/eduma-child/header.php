<?php
if ( e_is_frontend_editor() ) {
    get_header('profile');
} else {
	get_header('main');
}