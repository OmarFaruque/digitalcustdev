<?php
/**
 * @author Deepen.
 * @created_on 7/24/19
 */
?>

<div class="webinar-course-curriculum-quiz-accordion white-popup-block mfp-hide" id="open-new-create-quiz-popup-<?php echo $curriculum['id'] ?>">
    <div class="message message-success create-new-sections-webinar">Create new quiz</div>
</div>
