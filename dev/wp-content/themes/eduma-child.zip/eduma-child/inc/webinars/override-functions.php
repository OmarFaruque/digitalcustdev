<?php 
if ( !function_exists( 'thim_get_page_title' ) ) {
	function thim_get_page_title( $custom_title, $front_title ) {
		$heading_title = esc_html__( 'Page title', 'eduma' );
		if ( get_post_type() == 'product' ) {
			if ( !empty( $custom_title ) ) {
				$heading_title = $custom_title;
			} else {
				$heading_title = woocommerce_page_title( false );
			}
		} elseif ( get_post_type() == 'lpr_course' || get_post_type() == 'lpr_quiz' || get_post_type() == 'lp_course' || get_post_type() == 'lp_quiz' || thim_check_is_course() || thim_check_is_course_taxonomy() ) {
			if ( is_single() ) {
				if ( !empty( $custom_title ) ) {
                    $heading_title = $custom_title;
				} else {
					$course_cat = get_the_terms( get_the_ID(), 'course_category' );
					$course_tag = learn_press_is_course_tag();
					if ( !empty( $course_cat ) ) {
						$heading_title = $course_cat[0]->name;
					} elseif ( $course_tag ) {
						remove_query_arg( 'none' );
						$term          = get_term_by( 'slug', get_query_var( 'term' ), get_query_var( 'taxonomy' ) );
						$heading_title = $term->name;
					} else {
                        $heading_title = __( 'Course', 'eduma' );
                        $term          = get_term_by( 'slug', get_query_var( 'term' ), get_query_var( 'taxonomy' ) );


                        if($term){
                            switch($term->taxonomy){
                                case 'webinar_categories':
                                case 'webinar_tag':
                                    $heading_title = $term->name;
                                break;
                            }
                        }
                        $course_type = get_post_meta( get_the_ID(), '_course_type', true );
                        if($course_type == 'webinar'){
                            $heading_title = get_the_title( get_the_ID() );
                        }                        

                    }
                    
				}
			} else {
				$heading_title = thim_learnpress_page_title( false );
			}
		} elseif ( get_post_type() == 'lp_collection' ) {
			$heading_title = learn_press_collections_page_title( false );
		} elseif ( ( is_category() || is_archive() || is_search() || is_404() ) && !thim_use_bbpress() ) {
			if ( get_post_type() == 'tp_event' ) {
				$heading_title = esc_html__( 'Events', 'eduma' );
			} elseif ( get_post_type() == 'our_team' ) {
				$heading_title = esc_html__( 'Our Team', 'eduma' );
			} else {
				$heading_title = thim_archive_title();
			}
		} elseif ( thim_use_bbpress() ) {
			$heading_title = thim_forum_title();
		} elseif ( is_page() || is_single() ) {
			if ( is_single() ) {
				if ( $custom_title ) {
					$heading_title = $custom_title;
				} else {
					$heading_title = get_the_title();
					if ( get_post_type() == 'post' ) {
						$category = get_the_category();
						if ( $category ) {
							//$category_id   = get_cat_ID( $category[0]->cat_name );
							$heading_title = $category[0]->cat_name;
						} else {
							$heading_title = get_the_title();
						}
					}
					if ( get_post_type() == 'tp_event' ) {
						$heading_title = esc_html__( 'Events', 'eduma' );
					}
					if ( get_post_type() == 'portfolio' ) {
						//$heading_title = esc_html__( 'Portfolio', 'eduma' );
					}
					if ( get_post_type() == 'our_team' ) {
						$heading_title = esc_html__( 'Our Team', 'eduma' );
					}
					if ( get_post_type() == 'testimonials' ) {
						$heading_title = esc_html__( 'Testimonials', 'eduma' );
					}
				}

			} else {
				$heading_title = !empty( $custom_title ) ? $custom_title : get_the_title();
			}
		} elseif ( !is_front_page() && is_home() ) {
			$heading_title = !empty( $front_title ) ? $front_title : esc_html__( 'Blog', 'eduma' );;
		}

		return $heading_title;
	}
}



/**
 * Breadcrumb for LearnPress
 */
if ( ! function_exists( 'thim_learnpress_breadcrumb' ) ) {
	function thim_learnpress_breadcrumb() {
		// Do not display on the homepage
		if ( is_front_page() || is_404() ) {
			return;
		}
		$webinar_page_id  = learn_press_get_page_id( 'webinar' );

        
		// Get the query & post information
		global $post;
        $taxonomies = get_object_taxonomies( 'lp_course', 'objects' );
        
		// Build the breadcrums
		echo '<ul itemprop="breadcrumb" itemscope itemtype="http://schema.org/BreadcrumbList" id="breadcrumbs" class="breadcrumbs">';

        // Home page
        echo '<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem"><a itemprop="item" href="' . esc_html( get_home_url() ) . '" title="' . esc_attr__( 'Home', 'eduma' ) . '"><span itemprop="name">' . esc_html__( 'Home', 'eduma' ) . '</span></a></li>';
        
        
        
        $term = get_term_by( 'slug', get_query_var( 'term' ), get_query_var( 'taxonomy' ) );
        if($term){
            $termName = $term->name;
            switch($term->taxonomy){
                case 'webinar_categories':
                    $tax_label = $taxonomies['webinar_categories']->label;
                    echo '<li class="itemlistOM 1" itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem"><a itemprop="item" href="' . get_the_permalink( $webinar_page_id ) . '" title="' . $tax_label . '"><span itemprop="name">' . __('All Webinars', 'webinar') . '</span></a></li>';
                    echo '<li class="itemlistOM 2" itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem"><span itemprop="name">' . $termName . '</span></li>';
                break;
                case 'webinar_tag':
                    $tax_label = $taxonomies['webinar_tag']->label;
                    echo '<li class="itemlistOM 3" itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem"><a itemprop="item" href="' . get_the_permalink( $webinar_page_id ) . '" title="' . $tax_label . '"><span itemprop="name">' . __('All Webinars', 'webinar') . '</span></a></li>';
                    echo '<li class="itemlistOM 4" itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem"><span itemprop="name">' . $termName . '</span></li>';
                break;
            }
		}
		
        
        if( is_single() ) {
			$categories = get_the_terms( $post, 'course_category' );
			$postmetas = get_post_meta( $post->ID, '_course_type', true );
			if ( get_post_type() == 'lp_course' ) {
				// All courses
				if($postmetas == 'webinar'){
					echo '<li class="itemlistOM 9" itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem"><a itemprop="item" href="' . esc_url( get_the_permalink( $webinar_page_id ) ) . '" title="' . esc_attr__( 'All courses', 'eduma' ) . '"><span itemprop="name">' . esc_html__( 'All Webinars', 'eduma' ) . '</span></a></li>';
				}else{
					echo '<li class="itemlistOM 5" itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem"><a itemprop="item" href="' . esc_url( get_post_type_archive_link( 'lp_course' ) ) . '" title="' . esc_attr__( 'All courses', 'eduma' ) . '"><span itemprop="name">' . esc_html__( 'All courses', 'eduma' ) . '</span></a></li>';
				}
			}elseif ( learn_press_is_course_tag() ) {
				remove_query_arg( 'none' );
				$term = get_term_by( 'slug', get_query_var( 'term' ), get_query_var( 'taxonomy' ) );
				// All courses
				echo '<li class="tag66o" property="itemListElement" typeof="ListItem"><a property="item" typeof="WebPage" href="' . esc_url( get_post_type_archive_link( 'lp_course' ) ) . '" title="' . esc_attr__( 'All courses', 'eduma' ) . '"><span property="name">' . esc_html__( 'All courses', 'eduma' ) . '</span></a><meta property="position" content="2"></li>';
				echo '<li><span title="' . esc_attr( $term->name ) . '">' . esc_html( $term->name ) . '</span></li>';
			}else {
				if(get_the_title( get_post_meta( $post->ID, '_lp_course', true ) ) != '') echo '<li class="itemlistOM 6" itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem"><a itemprop="item" href="' . esc_url( get_permalink( get_post_meta( $post->ID, '_lp_course', true ) ) ) . '" title="' . esc_attr( get_the_title( get_post_meta( $post->ID, '_lp_course', true ) ) ) . '"><span itemprop="name">' . esc_html( get_the_title( get_post_meta( $post->ID, '_lp_course', true ) ) ) . '</span></a></li>';
			}

			// Single post (Only display the first category)
			if ( isset( $categories[0] ) ) {
				echo '<li class="itemlistOM 7" itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem"><a itemprop="item" href="' . esc_url( get_term_link( $categories[0] ) ) . '" title="' . esc_attr( $categories[0]->name ) . '"><span itemprop="name">' . esc_html( $categories[0]->name ) . '</span></a></li>';
			}
			if(get_the_title() != '') echo '<li class="itemlistOM 81" itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem"><span itemprop="name" title="' . esc_attr( get_the_title() ) . '">' . esc_html( get_the_title() ) . '</span></li>';

		} else if ( learn_press_is_course_taxonomy() || learn_press_is_course_tag() ) {
            
			// All courses
			echo '<li class="allcourse" itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem"><a itemprop="item" href="' . esc_url( get_post_type_archive_link( 'lp_course' ) ) . '" title="' . esc_attr__( 'All courses', 'eduma' ) . '"><span itemprop="name">' . esc_html__( 'All courses', 'eduma' ) . '</span></a></li>';

			// Category page
			echo '<li class="itemlistOM 8" itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem"><span itemprop="name" title="' . esc_attr( learn_press_single_term_title( '', false ) ) . '">' . esc_html( learn_press_single_term_title( '', false ) ) . '</span></li>';
		} else if ( ! empty( $_REQUEST['s'] ) && ! empty( $_REQUEST['ref'] ) && ( $_REQUEST['ref'] == 'course' ) ) {
            
			// All courses
			echo '<li  class="allcourse" itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem"><a itemprop="item" href="' . esc_url( get_post_type_archive_link( 'lp_course' ) ) . '" title="' . esc_attr__( 'All courses', 'eduma' ) . '"><span itemprop="name">' . esc_html__( 'All courses', 'eduma' ) . '</span></a></li>';

			// Search result
			echo '<li class="itemlistOM 9" itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem"><span itemprop="name" title="' . esc_attr__( 'Search results for:', 'eduma' ) . ' ' . esc_attr( get_search_query() ) . '">' . esc_html__( 'Search results for:', 'eduma' ) . ' ' . esc_html( get_search_query() ) . '</span></li>';
		} else {
			echo '<li  class="allcourse" itemprop="itemListElement-1" itemscope itemtype="http://schema.org/ListItem"><span itemprop="name" title="' . esc_attr__( 'All courses', 'eduma' ) . '">' . esc_html__( 'All courses', 'eduma' ) . '</span></li>';
        }
		echo '</ul>';
	}
}



if ( !function_exists( 'thim_item_meta_duration' ) ) {
	function thim_item_meta_duration( $item ) {
		$duration = $item->get_duration();
		$item_id = $item->get_id();
		$date = get_post_meta( $item_id, '_lp_webinar_when', true );
		
		$date = str_replace('/', '-', $date);
		
		$datewithDuration = date('Y-m-d h:i:s', strtotime($date) + $duration->get() );
		$wnewtime = date('Y-m-d h:i:s a', time());
		
		$progress  = strtotime($datewithDuration) - strtotime($wnewtime);
		
		if ( is_a( $duration, 'LP_Duration' ) && $duration->get() ) {
			$format = array(
				'day'    => _x( '%s day', 'duration', 'eduma' ),
				'hour'   => _x( '%s hour', 'duration', 'eduma' ),
				'minute' => _x( '%s min', 'duration', 'eduma' ),
				'second' => _x( '%s sec', 'duration', 'eduma' ),
			);

			if($date){
				$metaDuration = '';
				// if( strtotime($date) > strtotime($wnewtime) ) $metaDuration = __('Date', 'webinar') . ': ' . date('d.m.Y H:i', strtotime($date)) .' & '.__('Duration', 'webinar').': ' . $duration->to_timer( $format, true );
				if( strtotime($date) > strtotime($wnewtime) ) $metaDuration = __('Date', 'webinar') . ': ' . date('d.m.Y', strtotime($date)) .' in '.date('H:i', strtotime($date)).'   '.__('Duration', 'webinar').': ' . $duration->to_timer( $format, true );
				if($progress  >= 0 && $progress <= $duration->get() ) $metaDuration = __('In Progress', 'webinars');
				if(strtotime($datewithDuration) < strtotime($wnewtime) ) $metaDuration = __('Passed', 'webinars');
				echo '<span class="meta hh duration">' . $metaDuration . '</span>';
				
			}else{
				echo '<span class="meta duration">' . $duration->to_timer( $format, true ) . '</span>';
			}
		} elseif ( is_string( $duration ) && strlen( $duration ) ) {
			echo '<span class="meta dd duration">' . $duration . '</span>';
		}
	}
}


function is_rebon( $status ){
	$page = get_queried_object_id();
	// $course_page_id = learn_press_get_page_id( 'webinar' );
	if($status !='') echo('<div class="ribbon ribbon-top-left"><span>'.$status.'</span></div>');
}


function thim_sc_get_wibner_categories( $cats = false ) {
	global $wpdb;
	$query = $wpdb->get_results( $wpdb->prepare(
		"
				  SELECT      t1.term_id, t2.name
				  FROM        $wpdb->term_taxonomy AS t1
				  INNER JOIN $wpdb->terms AS t2 ON t1.term_id = t2.term_id
				  WHERE t1.taxonomy = %s
				  AND t1.count > %d
				  ",
		'webinar_categories', 0
	) );

	if ( ! $cats ) {
		$cats = array();
	}
	if ( ! empty( $query ) ) {
		foreach ( $query as $key => $value ) {
			$cats[ $value->name ] = $value->term_id;
		}
	}

	return $cats;
}


function get_course_lessons($course_id){
	$course = learn_press_get_course( $course_id );
	$sections = $course->get_curriculum_raw();
	$lessons = array();
	if ( ! empty( $sections ) ) {
		foreach ( $sections as $section ) {
				if ( isset( $section['items'] ) && is_array( $section['items'] ) ) {
					foreach($section['items'] as $singleitem){
						if($singleitem['type'] == 'lp_lesson') array_push($lessons, $singleitem['id']);
					}
				}
		}
	}
	return $lessons;
}

// add_filter('rewrite_rules_array', 'poe_rewrite_rules');
// function poe_rewrite_rules($rules) {
//     $custom = array('page/([0-9]+)/?$' => 'index.php?page_id=11365&home=yes');
//     return $custom + $rules;
// }

// add_action( 'init', 'my_rewrites_init' );
// function my_rewrites_init(){
//     add_rewrite_rule(
//         'page/([^/]+)/?',
//         'index.php?page_id=11365&pa=$matches[1]',
//         'top' );
// }


add_action('init', 'dcc_rewrite_tags');
function dcc_rewrite_tags() {
    add_rewrite_tag('%page%', '([^&]+)');
}

add_action('init', 'dcc_rewrite_rules');
function dcc_rewrite_rules() {
	$pages = explode('/', $_SERVER['REQUEST_URI']);
	$pages = array_filter($pages);
	$paged = end($pages);
	$webinar_page_id = learn_press_get_page_id( 'webinar' );
    if(in_array('page', $pages) ) add_rewrite_rule('^webinars/(.+)/?$','index.php?page_id='.$webinar_page_id.'&paged='.$paged.'','top');
}

if ( ! function_exists( 'thim_wrapper_loop_end' ) ) :
	function thim_wrapper_loop_end() {
		global $wp_query;
		global $post;
		$class_col = thim_wrapper_layout();
		$get_post_type = get_post_type();
		$course_type = get_post_meta( $post->ID, '_course_type', 'true' );

		if ( is_404() ) {
			$class_col = 'col-sm-12 full-width';
		}
		echo '</main>';

		$term_list =  $term = get_term_by( 'slug', get_query_var( 'term' ), get_query_var( 'taxonomy' ) );

		$webinar_page_id = learn_press_get_page_id( 'webinar' );
		$webinar = false;
		if($term_list){
			if($term_list->taxonomy == 'webinar_categories' || $term_list->taxonomy == 'webinar_tag') $webinar = true;
		}
		if ( $class_col != 'col-sm-12 full-width' ) {
			if ($get_post_type == "lpr_course" || $get_post_type == "lpr_quiz" || $get_post_type == "lp_course" || $get_post_type == "lp_quiz" || thim_check_is_course() || thim_check_is_course_taxonomy() ) {
				if($course_type == 'webinar') $webinar = true;
				if(!$webinar && !is_page($webinar_page_id)) get_sidebar( 'courses' );
				if($webinar) include(THIM_CHILD_THEME_DIR . 'inc/webinars/public/sidebar.php'); 
				
			} else if ( $get_post_type == "tp_event" ) {
				get_sidebar( 'events' );
			} else if ( $get_post_type == "product" ) {
				get_sidebar( 'shop' );
			} else {
				get_sidebar();
			}
		}
		echo '</div>';

		do_action( 'thim_after_site_content' );

		echo '</div>';
	}
endif;






//REtur function
function allcourseidsbytime($args, $session){
	// 	echo 'sesson: ' . $session . '<br/><br/>';
				$currentdate = date('Y-m-d h:i:s');
				$posts_ids = array();
				$getallcourse = get_posts($args);
				foreach($getallcourse as $scourse){
					$course_id = $scourse->ID;
					$lessons = get_course_lessons($course_id);
					$past = false;
					$future = false;
					foreach($lessons as $lesson){
						$lessonDate = get_post_meta( $lesson, '_lp_webinar_when', true );
						$lessonDate = str_replace('/', '-', $lessonDate);
						// echo 'course & session: '.$session.' (' . get_the_title($course_id) . '): '  . date('Y-m-d h:i:s', strtotime($lessonDate)) . '<br/>';
						$lessonDate = ($lessonDate) ? date('Y-m-d h:i:s', strtotime($lessonDate)) : '';
						if($lessonDate !='' && $lessonDate <= $currentdate) $past = true;
						if($lessonDate !='' && $lessonDate >= $currentdate) $future = true;
					} // End Foreach
					if($session == 'passed'){
						if($past && $future == false) array_push($posts_ids, $scourse->ID);
					}elseif($session == 'inprogress'){
						if($past == true && $future == true) array_push($posts_ids, $scourse->ID);
					}else{
						if($past == false && $future == true) array_push($posts_ids, $scourse->ID);
					}
				} // End Foreach
				if(count($posts_ids) <= 0 ) $posts_ids = array(0);
				return $posts_ids;
}


// Removes a class from the body_class array.
 
add_filter( 'body_class', 'customizebodyclass');
function customizebodyclass($class){
	global $post;	
	$webinar_page_id  = learn_press_get_page_id( 'webinar' );
	
	if($webinar_page_id == $post->ID) $class[] = 'learnpress-archive-webinars';
	// if(is_post_type_archive( 'lp_course' )) $class[] = 'course-filter-active';
	return $class;
}

add_action( 'pre_get_posts', 'test' );
function test($query){
	if( $query->is_main_query() && !is_admin() && is_post_type_archive( 'lp_course' ) ) {
		$metaQuery = array(
			'relation' => 'OR', 
			array(
				'key' => '_course_type',
				'compare' => 'NOT EXISTS'
			)
		);
		$query->set( 'meta_query', $metaQuery );
		// $query->set( 'meta_key', '_course_type' );
		// $query->set( 'meta_compare', 'NOT EXISTS' );
	}
}



// lp_inheance file add 
require_once(get_stylesheet_directory() . '/inc/webinars/admin/lp_enhance.php');

// Move DigitalCustDev Core Theme Customizations plugin to child theme
require_once(get_stylesheet_directory() . '/digitalcustdev-core/digitalcustdev-core.php');


function thim_tab_profile_filter_titlecustomize( $tab_title, $key ) {
	switch ( $key ) {
		case 'instructor':
			$tab_title = '<i class="fa fa-male"></i><span class="text">' . esc_html__( 'Instructor', 'eduma' ) . '</span>';
			break;
	}
	return $tab_title;
}
add_filter( 'learn_press_profile_instructor_tab_title', 'thim_tab_profile_filter_titlecustomize', 200, 2 );






	/**
	 * Query own courses of an user.
	 *
	 * @param int    $user_id
	 * @param string $args
	 *
	 * @return LP_Query_List_Table
	 */
	function query_own_courses_custom( $user_id, $args = '' ) {
		global $wpdb, $wp;
		$paged = 1;

		if ( ! empty( $wp->query_vars['view_id'] ) ) {
			$paged = absint( $wp->query_vars['view_id'] );
		}

		$paged = max( $paged, 1 );
		$args  = wp_parse_args(
			$args, array(
				'paged'  => $paged,
				'limit'  => 10,
				'status' => ''
			)
		);


		if ( ! $user_id ) {
			$user_id = get_current_user_id();
		}

		$cache_key = sprintf( 'own-courses-%d-%s', $user_id, md5( build_query( $args ) ) );

		if ( false === ( $courses = LP_Object_Cache::get( $cache_key, 'learn-press/user-courses' ) ) ) {

			$courses = array(
				'total' => 0,
				'paged' => $args['paged'],
				'limit' => $args['limit'],
				'pages' => 0,
				'items' => array()
			);

			try {

				//$orders = $this->get_orders( $user_id );
				$query = array( 'total' => 0, 'pages' => 0, 'items' => false );

//				//if ( ! $orders ) {
//				//	throw new Exception( "Error", 0 );
//				//}
//
//				//$course_ids   = array_keys( $orders );
//				//$query_args   = $course_ids;
//				$query_args[] = $user_id;
				$limit  = $args['limit'];
				$where  = "WHERE 1";
				$offset = ( $args['paged'] - 1 ) * $limit;

				if ( ! empty( $args['status'] ) ) {
					if ( is_array( $args['status'] ) ) {
						$a     = array_fill( 0, sizeof( $where ), '%d' );
						$where .= $wpdb->prepare( " AND post_status IN(" . join( ',', $where ) . ")", $a );
					} else {
						if ( 'pending' === $args['status'] ) {
							$where .= $wpdb->prepare( " AND post_status IN( %s, %s )", array( 'draft', 'pending' ) );
						} elseif ( $args['status'] !== '*' ) {
							$where .= $wpdb->prepare( " AND post_status = %s", $args['status'] );
						}
					}
				} else {
					$where .= $wpdb->prepare( " AND post_status NOT IN (%s, %s)", array( 'trash', 'auto-draft' ) );
				}

				$where = $where . $wpdb->prepare( " AND post_type = %s AND post_author = %d", LP_COURSE_CPT, $user_id );
				if(isset($args['orderby']) && isset($args['order'])){
					$where .= $wpdb->prepare( " ORDER BY post_date DESC");
				} 
				$sql   = "
					SELECT SQL_CALC_FOUND_ROWS ID
					FROM {$wpdb->posts} c
					{$where} 
					LIMIT {$offset}, {$limit}
				";


				$items = $wpdb->get_results( $sql );

				if ( $items ) {
					$count      = $wpdb->get_var( "SELECT FOUND_ROWS()" );
					$course_ids = wp_list_pluck( $items, 'ID' );
					LP_Helper::cache_posts( $course_ids );

					$courses['total'] = $count;
					$courses['pages'] = ceil( $count / $args['limit'] );
					foreach ( $items as $item ) {
						$courses['items'][] = $item->ID;
					}
				}
			}
			catch ( Exception $ex ) {
				learn_press_add_message( $ex->getMessage() );
			}

			LP_Object_Cache::set( $cache_key, $courses, 'learn-press/user-courses' );
		}

		$courses['single'] = __( 'course', 'learnpress' );
		$courses['plural'] = __( 'courses', 'learnpress' );

		return new LP_Query_List_Table( $courses );
	}
